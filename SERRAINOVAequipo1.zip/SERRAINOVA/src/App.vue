<script setup lang="ts">
import AppHeader from './components/AppHeader.vue'
import AppFooter from './components/AppFooter.vue'
</script>

<template>
  <div class="relative flex min-h-screen w-full flex-col">
    <AppHeader />
    <router-view />
    <AppFooter />
  </div>
</template>

<style scoped>
</style>
