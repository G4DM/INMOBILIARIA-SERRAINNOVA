// Datos de usuarios simulados para el panel de administrador
export interface User {
    id: number
    name: string
    email: string
    registrationDate: string
    phone?: string
    lastLogin?: string
}

export const users: User[] = [
    {
        id: 1,
        name: 'María García López',
        email: 'maria.garcia@email.com',
        registrationDate: '2026-01-15',
        phone: '+34 612 345 678',
        lastLogin: '2026-02-09'
    },
    {
        id: 2,
        name: 'Juan Martínez Ruiz',
        email: 'juan.martinez@email.com',
        registrationDate: '2026-01-20',
        phone: '+34 623 456 789',
        lastLogin: '2026-02-10'
    },
    {
        id: 3,
        name: 'Ana Fernández Sánchez',
        email: 'ana.fernandez@email.com',
        registrationDate: '2026-01-25',
        phone: '+34 634 567 890',
        lastLogin: '2026-02-08'
    },
    {
        id: 4,
        name: 'Carlos López Pérez',
        email: 'carlos.lopez@email.com',
        registrationDate: '2026-02-01',
        phone: '+34 645 678 901',
        lastLogin: '2026-02-10'
    },
    {
        id: 5,
        name: 'Laura Rodríguez Gómez',
        email: 'laura.rodriguez@email.com',
        registrationDate: '2026-02-05',
        phone: '+34 656 789 012',
        lastLogin: '2026-02-09'
    }
]
